<?php 
	
echo  "Bonjour nous sommes le ". date("D d/M/Y");



?>