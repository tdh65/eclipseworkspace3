//  
// <br> Envoi du fichier : <?php htmlspecialchars($_POST['monfichier0']); ?>. </br>
// <br> lien interne : <?php isset($_FILES['monfichier0']['name']); ?>. </br>
 // <br> lien interne Taille: <?php isset($_FILES['monfichier0']['size']); ?>.</br> 

<p> <a href="form1.php">Retour Saisie </a> pour revenir à la page form1.php.</p>
<p>Si tu veux changer de valeurs, <a href="form1.php">clique ici</a> pour revenir à la page form1.php.</p>
<p> <a href="bonjour.php"> test de bonjour </a> .</p>
<?php
// Testons si le fichier a bien été envoyé et s'il n'y a pas d'erreur
if (isset($_FILES['monfichier0']) AND $_FILES['monfichier0']['error'] == 0)
{
	 // Testons si le fichier n'est pas trop gros
        if ($_FILES['monfichier0']['size'] <= 1000000)
        {
 		$NomFic = $_FILES['nomfichier0']['name'];
		$NomTmp = $_FILES['nomfichier0']['tmp_name'];
        	echo '<br>  le fichier est inférieur a 1 Mo </br>';

		echo '<br>  le fichier' . $_FILES['nomfichier0']['name'] . ' est reçu </br>';
		echo '<br> Liste des valeurs pour tmp </br>' ;
		echo '<br>  le fichier name ' . $nomfic .  ' reçu  </br>';		
		echo '<br>  le fichier tmp ' . $nomtmp .  ' reçu ! </br>';
		echo '<br>  le fichier  est reçu 5656565656! </br>';
		echo '<br> Acceptation du fichier </br>';
		// Testons si l'extension est autorisée
                $infosfichier = pathinfo($_FILES['monfichier0']['name']);
                $extension_upload = $infosfichier['extension'];
                $extensions_autorisees = array('txt', 'sql', 'mp3','mp4','avi', 'png');
		echo ' $ infos fichier : ' . $infosfichier . ' pp .' ;
		echo ' $ extension :  ' . $extension_upload . ' pp . '; 
                if (in_array($extension_upload, $extensions_autorisees))
                {
                        // On peut valider le fichier et le stocker définitivement
			echo "Basename " ;
			echo basename($_FILES['monfichier0']['name']);
			echo '<br>Nom fichier </br>';
			echo $_FILES['monfichier0']['name'];
			echo '<br>tmp_name</br>';
			echo $_FILES['monfichier0']['tmp_name'];
			echo '<br>size </br>';
			echo $_FILES['monfichier0']['size'];
			echo '<br>type</br>';
			echo $_FILES['monfichier0']['type'];
			echo '<br>error</br>';
			echo $_FILES['monfichier0']['error'];
			echo '<br></br>';
                        move_uploaded_file($_FILES['monfichier0']['tmp_name'], 'uploads/' . basename($_FILES['monfichier0']['name']));
                        echo "L'envoi a bien été effectué !";
			echo "le nom du fichier " ;
			echo $NomFic;
                }

	}
	
}
else 
{
	echo '<br>  le fichier ' . $_FILES['monfichier0']['tmp_name'] .  ' non reçu ! </br>';
	echo '<br>  le fichier ELSE LESE  999999999999 Fuck! </br>';
	echo 'Erreur ' .$_FILES['monfichier0']['error'] .'.';
}
echo phpinfo();
?>

