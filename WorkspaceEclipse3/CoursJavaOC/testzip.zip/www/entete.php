<div id="entete">        
   <div class="element_entete">
	   <h3>Titre entete</h3>
	   <ul>
		   <li><a href="page1.html">Lien</a></li>
		   <li><a href="page2.html">Lien</a></li>
		   <li><a href="page3.html">Lien</a></li>
	   </ul>
   </div>    
</div>

