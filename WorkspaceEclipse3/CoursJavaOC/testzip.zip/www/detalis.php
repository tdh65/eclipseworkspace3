html>
 <head>
  <title>Test PHP</title>
 </head>
 <body>
 <?php echo '<p>Bonjour le monde</p>'; ?>
<br><?php phpinfo(); ?> </br>
 </body>
</html>
