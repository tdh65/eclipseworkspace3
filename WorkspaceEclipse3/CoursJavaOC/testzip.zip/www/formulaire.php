<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
// reference http://www.siteduzero.com/tutoriel-3-220325-correction.html
	<head>
		<title>Page protégée par mot de passe</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	</head>
	<body>
		<p>Veuillez entrer le mot de passe pour obtenir les codes d'accès au serveur central de la NASA :</p>
		<form action="secret.php" method="post">
			<p>
			<input type="password" name="mot_de_passe" />
			<input type="submit" value="Valider" />
			</p>
		</form>
		<p>Cette page est réservée au personnel de la NASA. Si vous ne travaillez pas à la NASA, inutile d'insister vous ne trouverez jamais le mot de passe ! ;-)</p>
	</body>
</html>

