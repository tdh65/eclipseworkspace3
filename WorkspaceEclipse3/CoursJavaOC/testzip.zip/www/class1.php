<?php
class foo
{
    function do_foo()
    {
        echo "Doing foo.Beurk";
    }
}

$bar = new foo;
$bar->do_foo();
?>
