<?php
$age_du_visiteur = 17;
echo 'Le visiteur a ' . $age_du_visiteur . ' ans';
?>
<?php
$age_du_visiteur = 17;
echo "Le visiteur a $age_du_visiteur ans";
?>

