
<?php include("entete.php"); ?>
<?php
$nombre = 10 % 5; // $nombre prend la valeur 0 car la division tombe juste
echo $nombre 

?>
<br></br>
<?php
$nombre = 10 % 3; // $nombre prend la valeur 1 car il reste 1
echo "Nombre : " . $nombre 
?>
<?php
$coordonnees = array (
    'prenom' => 'François',
    'nom' => 'Dupont',
    'adresse' => '3 Rue du Paradis',
    'ville' => 'Marseille' ) ;/* , 
	'prenom'=>'Rene', 'nom' => 'DUCUING' , 'adresse'=>'5 rue de Castelbajac' , 'Ville'=>'Castelbajac' ); */
 
foreach($coordonnees as $element)
{
    echo $element . '<br />';
}
?>
