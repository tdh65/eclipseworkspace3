<html>
	
<?php
	echo "Name : " .$_POST ["nom"] ."!" 
	
?>
</html>