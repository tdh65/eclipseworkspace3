<form action="action.php" method="post">
 <p>Votre nom : <input type="text" name="nom" /></p>
 <p>Votre âge : <input type="text" name="age" /></p>
 <textarea name="message" rows="8" cols="45">
 Votre message ici.
</textarea>
<p></p>
<select name="choix">
    <option value="choix1">Choix 1</option>
    <option value="choix2">Choix 2</option>
    <option value="choix3" selected="selected">Choix 3</option>
    <option value="choix4">Choix 4</option>
	
</select>

<p></p>
<input type="checkbox" name="case" id="case" /> <label for="case">Ma case à cocher</label>


<p>-------------------------------------!!!-----------------------------------------</p>

Aimez-vous les frites ?
<input type="radio" name="frites" value="oui" id="oui" checked="checked" /> <label for="oui">Oui</label>
<input type="radio" name="frites" value="non" id="non" /> <label for="non">Non</label>

<p>-------------------------------------!!!-----------------------------------------</p>
<input type="hidden" name="pseudo" value="Mateo21" />
<p>-------------------------------------!!!-----------------------------------------</p>
 <p><input type="submit" value="OK"></p>
</form>
<p>-------------------------------------!!!-----------------------------------------</p>
<br><center><strong>Envoi de fichier ;=))) </strong> </center></br>
lien http://www.siteduzero.com/tutoriel-3-14539-l-envoi-de-fichiers.html
<form action="cible_envoi.php" method="post" enctype="multipart/form-data">
        <p>
        	 Formulaire d'envoi de fichier :</br>
                <input type="file" name="monfichier0" ></br>
                <input type="submit" value="Envoyer le fichier" />
        </p>
</p>

</form>


