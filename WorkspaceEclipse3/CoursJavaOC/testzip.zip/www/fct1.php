<?php

function somefun($sub ) 
	{
		echo $sub." ==> Pogues hup own.";
}

function add ($a ,$b) 
{
	$total = $a+$b; 
	return $total;
}
somefun ("trioe de caen " ) ;
somefun ("punta des extedsdd" ) ;
echo " 5 + 696 = " . add(5,696) ." et la tete a toto ." ;

?>
