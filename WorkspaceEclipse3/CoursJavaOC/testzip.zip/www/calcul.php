
<?php include("entete.php"); ?>
<?php
$nombre = 10 % 5; // $nombre prend la valeur 0 car la division tombe juste
echo $nombre 

?>
<br></br>
<?php
$nombre = 10 % 3; // $nombre prend la valeur 1 car il reste 1
echo $nombre
?>

