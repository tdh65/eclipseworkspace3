<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Mon super site</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
   </head>
 
	<body>
 
        <?php include("entete.php"); ?>
 
        <?php include("menu.php"); ?>
  
        <div id="corps">
           <h1>Mon super site</h1>
       
			<p>
               Bienvenue sur mon super site !<br />
               Vous allez adorer ici, c'est un site génial qui va parler de... euh... Je cherche encore un peu le thème de mon site. :-D
			</p>
        </div>
  
        <?php include("pieddepage.php"); ?>
 
   </body>
</html>

