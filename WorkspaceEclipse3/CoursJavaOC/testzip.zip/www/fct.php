<?php
function DireBonjour($nom)
{
    echo '<br>Bonjour ' . $nom . '.!</br>';
}

DireBonjour('Marie');
DireBonjour('Patrice');
DireBonjour('Edouard');
DireBonjour('Pascale');
DireBonjour('François');
DireBonjour('Benoît');
DireBonjour('Père Noël');
?>

