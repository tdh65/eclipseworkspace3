<?php 
	$actions = array('fingers' =>'Hands' , 'toes'=>'patat' , 'teeth'=>'mouth' ) ;
	echo $action['fingers'];
	$name[] = "Matt" ; 
	$name[] = "Cokie" ;
	$name[]= "SKUh" ;
	/*for ( $i = 0 ; $i < sizeof($name ) ;  $i++ )
		echo "i :". $i . " value " . $name[$i] ." ..."  */;
	/* for ($i=0 ; $i < sizeof($action) ; $i++ ) */
	foreach ($name as $i)
		echo $i ; 
	for ( $i = 0 ; $i < sizeof($action ) ;  $i++ )
		echo "i :". $i . " value " . $action[$i] ." ...";
	echo $actions["fingers"];
	echo $actions["toes"];
	
	
	?>
	
		<html>
		<body>
		<form action = "action2.php"  method="post" >
		 <p>Nom :<input type="text" name="nom"  /></p>
		<p><input type="submit"  /></p>
		


<p>-------------------------------------!!!-----------------------------------------</p>

Aimez-vous les frites ?
<input type="radio" name="frites" value="oui" id="oui" checked="checked" /> <label for="oui">Oui</label>
<input type="radio" name="frites" value="non" id="non" /> <label for="non">Non</label>

<p>-------------------------------------!!!-----------------------------------------</p>

		</form>
		</body>
		</html>