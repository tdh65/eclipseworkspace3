// trouve sur http://fr2.php.net/manual/fr/function.getdate.php 
//A function/method to calculate the next workday, taking into account US federal holidays:
<?php
function getNextWorkDayTime($date=null)
{
    $time = is_string($date) ? strtotime($date) : (is_int($date) ? $date : time());
    $y = date('Y', $time);
    // calculate federal holidays
    $holidays = array();
    // month/day (jan 1st). iteration/wday/month (3rd monday in january)
    $hdata = array('1/1'/*newyr*/, '7/4'/*jul4*/, '11/11'/*vet*/, '12/25'/*xmas*/, '3/1/1'/*mlk*/, '3/1/2'/*pres*/, '5/1/5'/*memo*/, '1/1/9'/*labor*/, '2/1/10'/*col*/, '4/4/11'/*thanks*/);
    foreach ($hdata as $h1) {
        $h = explode('/', $h1);
        if (sizeof($h)==2) { // by date
            $htime = mktime(0, 0, 0, $h[0], $h[1], $y); // time of holiday
            $w = date('w', $htime); // get weekday of holiday
            $htime += $w==0 ? 86400 : ($w==6 ? -86400 : 0); // if weekend, adjust
        } else { // by weekday
            $htime = mktime(0, 0, 0, $h[2], 1, $y); // get 1st day of month
            $w = date('w', $htime); // weekday of first day of month
            $d = 1+($h[1]-$w+7)%7; // get to the 1st weekday
            for ($t=$htime, $i=1; $i<=$h[0]; $i++, $d+=7) { // iterate to nth weekday
                 $t = mktime(0, 0, 0, $h[2], $d, $y); // get next weekday
                 if (date('n', $t)>$h[2]) break; // check that it's still in the same month
                 $htime = $t; // valid
            }
        }
        $holidays[] = $htime; // save the holiday
    }
    for ($i=0; $i<5; $i++, $time+=86400) { // 5 days should be enough to get to workday
        if (in_array(date('w', $time), array(0, 6))) continue; // skip weekends
        foreach ($holidays as $h) { // iterate through holidays
            if ($time>=$h && $time<$h+86400) continue 2; // skip holidays
        }
        break; // found the workday
    }
    return $time;
}
?> 
